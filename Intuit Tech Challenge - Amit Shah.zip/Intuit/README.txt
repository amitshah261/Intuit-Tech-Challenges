Intuit Tech Challenge.


I have analyzed the customer data in SQL to identify the type of Transactions.

Once that is done i have exported the file to Excel and analyzed the data further.

Steps:
1. Import all the text files given in the zip folder in MS SQL Server.
2. Run query on SQL.
3. Analyze the data in Excel
4. Import the result back into SQL.

